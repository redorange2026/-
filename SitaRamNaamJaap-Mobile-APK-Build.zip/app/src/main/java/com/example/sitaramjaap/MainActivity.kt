package com.example.sitaramjaap

import android.Manifest
import android.content.Intent
import android.media.MediaPlayer
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Saffron = Color(0xFFB95718)
private val DeepBrown = Color(0xFF713514)
private val Cream = Color(0xFFFFF5E6)
private val Gold = Color(0xFFE5A33B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("jaap_counter", MODE_PRIVATE)
        setContent {
            var total by remember { mutableIntStateOf(prefs.getInt("total", 0)) }
            var today by remember { mutableIntStateOf(prefs.getInt("today", 0)) }
            var savedDate by remember { mutableStateOf(prefs.getString("date", todayKey()) ?: todayKey()) }
            var previousTotal by remember { mutableIntStateOf(total) }
            var previousToday by remember { mutableIntStateOf(today) }
            var showReset by remember { mutableStateOf(false) }
            var soundOn by remember { mutableStateOf(true) }
            var listeningMessage by remember { mutableStateOf("वॉइस कमांड के लिए माइक दबाएँ") }
            var lastPujaAction by remember { mutableStateOf("पूजा के लिए कोई क्रिया चुनें") }

            if (savedDate != todayKey()) {
                today = 0
                savedDate = todayKey()
                prefs.edit().putInt("today", 0).putString("date", savedDate).apply()
            }

            fun persist() {
                prefs.edit().putInt("total", total).putInt("today", today)
                    .putString("date", savedDate).apply()
            }
            fun increment(amount: Int = 1) {
                previousTotal = total
                previousToday = today
                total += amount
                today += amount
                persist()
            }

            val context = LocalContext.current
            var tts by remember { mutableStateOf<TextToSpeech?>(null) }
            DisposableEffect(context) {
                val engine = TextToSpeech(context) { status ->
                    if (status == TextToSpeech.SUCCESS) {
                        tts?.language = Locale("hi", "IN")
                    }
                }
                tts = engine
                onDispose { engine.stop(); engine.shutdown(); tts = null }
            }
            fun speak(text: String) {
                if (soundOn) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sita_ram_jaap")
            }
            fun playPujaSound(resourceId: Int, announcement: String) {
                lastPujaAction = announcement
                if (soundOn) {
                    val player = MediaPlayer.create(context, resourceId)
                    player?.setOnCompletionListener { it.release() }
                    player?.start()
                }
            }
            fun performPuja(action: String) {
                when (action) {
                    "घंटी" -> playPujaSound(R.raw.temple_bell, "मंदिर की घंटी")
                    "शंख" -> playPujaSound(R.raw.shankh, "शंख ध्वनि")
                    "आरती" -> {
                        lastPujaAction = "श्री सीताराम जी की आरती"
                        speak("श्री सीताराम जी की आरती प्रारंभ। जय सियाराम। आरती कीजै हनुमान लला की। दुष्ट दलन रघुनाथ कला की। श्री रामचंद्र जी की जय। सीता माता की जय।")
                    }
                    "स्नान" -> {
                        lastPujaAction = "स्नान एवं शुद्धि मंत्र"
                        speak("भगवान श्री सीताराम के अभिषेक का भाव करें। ॐ अपवित्रः पवित्रो वा सर्वावस्थां गतोपि वा। यः स्मरेत पुण्डरीकाक्षं स बाह्याभ्यन्तरः शुचिः। ॐ श्री सीतारामाय नमः।")
                    }
                    "पूजा" -> {
                        lastPujaAction = "श्री सीताराम पूजन मंत्र"
                        speak("ॐ श्री गणेशाय नमः। ॐ श्री सीतारामाय नमः। पुष्पं समर्पयामि। धूपं समर्पयामि। दीपं दर्शयामि। नैवेद्यं निवेदयामि। जय सियाराम।")
                    }
                    "प्रसाद" -> {
                        lastPujaAction = "प्रसाद अर्पण मंत्र"
                        speak("ॐ सह नाववतु। सह नौ भुनक्तु। श्री सीताराम प्रभु को प्रेमपूर्वक भोग अर्पित है। सभी भक्तों को प्रसाद प्राप्त हो। जय सियाराम।")
                    }
                    else -> {
                        lastPujaAction = "$action — जय श्री सीताराम"
                        speak("$action प्रारंभ। जय श्री सीताराम")
                    }
                }
            }

            val speechLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.StartActivityForResult()
            ) { result ->
                val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                    ?.firstOrNull()?.lowercase(Locale("hi", "IN")).orEmpty()
                listeningMessage = if (spoken.isBlank()) "आवाज़ समझ नहीं आई" else "आपने कहा: $spoken"
                when {
                    spoken.contains("रीसेट") -> showReset = true
                    spoken.contains("कितने") || spoken.contains("गिनती") -> speak("अब तक कुल $total सीताराम नाम जाप हुए हैं")
                    spoken.contains("माला") && (spoken.contains("पूरी") || spoken.contains("जोड़")) -> increment((108 - total % 108).let { if (it == 0) 108 else it })
                    spoken.contains("जाप") || spoken.contains("सीताराम") -> {
                        val amount = Regex("\\d+").find(spoken)?.value?.toIntOrNull()?.coerceIn(1, 10000) ?: 1
                        increment(amount)
                        speak("सीताराम")
                    }
                    else -> speak("कृपया कहें, जाप करो, कितने जाप हुए, या रीसेट करो")
                }
            }
            val permissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestPermission()
            ) { granted ->
                if (granted) {
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                        putExtra(RecognizerIntent.EXTRA_PROMPT, "कहें: जाप करो, कितने जाप हुए, या रीसेट करो")
                    }
                    runCatching { speechLauncher.launch(intent) }
                        .onFailure { listeningMessage = "इस फोन पर वॉइस पहचान उपलब्ध नहीं है" }
                } else listeningMessage = "वॉइस कमांड के लिए माइक्रोफोन अनुमति चाहिए"
            }

            MaterialTheme(colorScheme = lightColorScheme(
                primary = Saffron, onPrimary = Color.White,
                background = Cream, surface = Color.White
            )) {
                Box(Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(R.drawable.sita_ram_bg),
                        contentDescription = "सीता राम का भक्तिमय चित्र",
                        modifier = Modifier.fillMaxSize().alpha(0.24f),
                        contentScale = ContentScale.Crop
                    )
                    JaapScreen(
                        total = total, today = today, soundOn = soundOn,
                        listeningMessage = listeningMessage,
                        onTap = { increment(); speak("सीताराम") },
                        onUndo = {
                            if (total > 0 && today > 0) {
                                total = previousTotal.coerceAtMost(total - 1)
                                today = previousToday.coerceAtMost(today - 1)
                                persist()
                            }
                        },
                        onReset = { showReset = true },
                        onToggleSound = { soundOn = it },
                        onVoice = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                        lastPujaAction = lastPujaAction,
                        onPujaAction = { performPuja(it) }
                    )
                }
                if (showReset) {
                    AlertDialog(
                        onDismissRequest = { showReset = false },
                        title = { Text("गिनती रीसेट करें?") },
                        text = { Text("क्या आप कुल और आज की जाप गिनती शून्य करना चाहते हैं?") },
                        confirmButton = {
                            TextButton(onClick = {
                                total = 0; today = 0
                                previousTotal = 0; previousToday = 0
                                persist(); showReset = false
                            }) { Text("रीसेट करें") }
                        },
                        dismissButton = {
                            TextButton(onClick = { showReset = false }) { Text("रहने दें") }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun JaapScreen(
    total: Int, today: Int, soundOn: Boolean, listeningMessage: String,
    onTap: () -> Unit, onUndo: () -> Unit, onReset: () -> Unit,
    onToggleSound: (Boolean) -> Unit, onVoice: () -> Unit,
    lastPujaAction: String, onPujaAction: (String) -> Unit
) {
    val mala = total / 108
    val inMala = total % 108
    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFFFFE0A3), Color(0xFFFFF3D9), Color(0xFFFFD18A)))
        ),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(13.dp),
            modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())
        ) {
            Text("🙏  ॥ श्री सीताराम ॥  🙏", fontSize = 27.sp, color = DeepBrown, fontWeight = FontWeight.Bold)
            Text("नाम जाप काउंटर", fontSize = 14.sp, color = Saffron)
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFAF0).copy(alpha = .94f)),
                shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("कुल नाम जाप", color = DeepBrown, fontSize = 15.sp)
                    Text(total.toString(), color = Saffron, fontSize = 44.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Stat("आज का जाप", today.toString())
                        Stat("पूरी माला", mala.toString())
                        Stat("इस माला में", "$inMala / 108")
                    }
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(progress = { inMala / 108f },
                        modifier = Modifier.fillMaxWidth().height(8.dp),
                        color = Saffron, trackColor = Color(0xFFF3D8B5))
                }
            }
            Box(
                modifier = Modifier.size(174.dp).background(
                    Brush.radialGradient(listOf(Color(0xFFFFD27A), Saffron, DeepBrown)), CircleShape
                ).padding(9.dp).background(Color(0xFFFFE5B4), CircleShape).clickable { onTap() },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("सीताराम", color = DeepBrown, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("जाप करने के लिए दबाएँ", color = DeepBrown, fontSize = 11.sp)
                }
            }
            Text("हर टैप पर मधुर 'सीताराम' ध्वनि", color = DeepBrown, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = onVoice, colors = ButtonDefaults.buttonColors(containerColor = Saffron)) {
                    Icon(Icons.Default.Mic, contentDescription = null)
                    Spacer(Modifier.width(5.dp)); Text("वॉइस कमांड")
                }
                OutlinedButton(onClick = { onToggleSound(!soundOn) }) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null)
                    Text(if (soundOn) "ध्वनि चालू" else "ध्वनि बंद")
                }
            }
            Text(listeningMessage, color = DeepBrown, fontSize = 12.sp, textAlign = TextAlign.Center)
            Text("कहें: “जाप करो”, “कितने जाप हुए?”, “रीसेट करो”", color = DeepBrown, fontSize = 11.sp, textAlign = TextAlign.Center)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = onUndo, shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Default.Undo, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("Undo")
                }
                OutlinedButton(onClick = onReset, shape = RoundedCornerShape(14.dp)) {
                    Icon(Icons.Default.Refresh, contentDescription = null); Spacer(Modifier.width(4.dp)); Text("रीसेट")
                }
            }
            if (inMala == 0 && total > 0) Text("🌸 एक माला पूर्ण हुई! जय सीताराम 🌸", color = Saffron)
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFAF0).copy(alpha = .96f)),
                shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("🪔 दैनिक पूजा सेवा", color = DeepBrown, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("अपनी पूजा की क्रिया चुनें", color = Saffron, fontSize = 12.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PujaButton("🪔 आरती", Modifier.weight(1f)) { onPujaAction("आरती") }
                        PujaButton("💧 स्नान", Modifier.weight(1f)) { onPujaAction("स्नान") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PujaButton("🌺 पूजा", Modifier.weight(1f)) { onPujaAction("पूजा") }
                        PujaButton("🔔 घंटी", Modifier.weight(1f)) { onPujaAction("घंटी") }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PujaButton("🐚 शंख", Modifier.weight(1f)) { onPujaAction("शंख") }
                        PujaButton("🍎 प्रसाद", Modifier.weight(1f)) { onPujaAction("प्रसाद") }
                    }
                    Text(lastPujaAction, color = DeepBrown, fontSize = 12.sp, textAlign = TextAlign.Center)
                    Text("घंटी और शंख के लिए अलग ध्वनि प्रभाव शामिल हैं।", color = Saffron, fontSize = 10.sp)
                }
            }
            Text("॥ जय सिया राम ॥", color = Saffron, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.widthIn(min = 76.dp)) {
        Text(value, color = Saffron, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(label, color = DeepBrown, fontSize = 11.sp, textAlign = TextAlign.Center)
    }
}

private fun todayKey(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
